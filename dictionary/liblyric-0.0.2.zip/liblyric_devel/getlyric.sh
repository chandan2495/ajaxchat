#/bin/sh

OPTSTRING=`getopt -o e:dhg -l engine:,debug,help,gui -- "$@"`

bad_domains="\.amazon\.\|\.overture\.\|\.dogpile\."

# echo "GetOpt return: "$?
# echo "Original arguments: "$@
# echo "OPTSTRING: "$OPTSTRING

eval set -- "$OPTSTRING"
# echo "New positional arguments: "$@

engine='ask'
debug=0
gui=0;

show_usage ()
{
  echo -e "Usage: getlyric \"[artist name song name]\" [--engine <engine name>]\n";
  echo -e "Options:\n";
  echo -e "-e|--engine ENGINE";
  echo -e "\tThe search engine to use. Options for ENGINE include ask, yahoo, google and dogpile.\n";
  echo -e "-d|--debug";
  echo -e "\tSpecify to enable debug output.\n";
  echo -e "-g|--gui";
  echo -e "\tUse GUI mode for output.\n";
  echo -e "-h|--help";
  echo -e "\tShow this usage screen.\n";
}

while true
do
  # echo "Argument: "$1
  case "$1" in
      -e|--engine) engine=$2; shift 2;;
      -d|--debug) debug=1; shift;;
      -g|--gui) gui=1; shift;;
      -h|--help) show_usage; exit;;
      --) song_title=$2; break;;
      *) echo "Incorrect argument: "$1; shift;;
  esac
done

if [ "$song_title" == "" ]
then
  echo "Please enter the song title you want to fetch the lyrics for."
  exit
fi


# echo "GUI == "$gui;


# $song_title is the search string.
# echo "Song title: "$song_title

search_str=`echo "$song_title" | ./get_search_str`
search_str=$search_str"+lyrics"
# echo "search_URL: "$search_URL


# echo $search_URL
# echo "The links found are:"
# curl $search_URL 2> /dev/null | ./get_links.sh "$grep_str" $cut_pos

# HREF_links=`curl $search_URL | ./get_links.sh $grep_str $cut_pos`

# echo "grep String: "$grep_str
# echo "Cut position: "$cut_pos

echo "Sending search string to www."$engine".com. Please wait...."
# echo $search_URL
# curl $search_URL

# tmp_dir=`curl $search_URL 2> /dev/null | grep "$grep_str" | cut -f $cut_pos -d "\"" | ./remove_duplicates.sh | ./find_best_match`
tmp_dir=`./do_search.sh "$search_str" --engine $engine \
  | grep -iv $bad_domains \
  | ./remove_duplicates.sh \
  | ./find_best_match`

# echo "after command"


# echo $tmp_dir

sort --reverse -g $tmp_dir/extents.txt | gawk '{ if ($2 > 32) print $0}' > $tmp_dir/ordered_exts.txt
num_entries=`cat $tmp_dir/ordered_exts.txt | wc | gawk '{ print $1 }'`

num_heads=2

if [ $num_entries -lt 2 ]
then
  if [ $num_entries -lt 1 ]
  then
    echo "Sorry, no matches were found.... :-("
    exit
  else
    num_heads=1
  fi
fi

ent_line=`head -n $num_heads $tmp_dir/ordered_exts.txt | tail -n 1`

ext_size=`echo $ent_line | cut -f 1 -d " "`
 ext_beg=`echo $ent_line | cut -f 2 -d " "`
ext_path=`echo $ent_line | cut -f 4 -d " "`


of_name="/dev/stdout";
if [ $gui -eq 1 ]
then
  of_name="$tmp_dir/lyric.out";
fi

dd if=$ext_path bs=1 count=$ext_size skip=$ext_beg 2> /dev/null \
  | gawk '{ sub(/[ \t]*/, ""); print $0 }' \
  | gawk '{ gsub(/[ ]+/, " "); print $0 }' > $of_name


if [ $gui -eq 1 ]
then
    dialog --textbox $tmp_dir/lyric.out 40 100
else
    echo ""
fi

# Get the number of words in the string (which is actually the line
# count in the actual output.
# num_res=`echo $HREF_links | wc | ./get_search_str | cut -d "+" -f 2`

# echo $num_res


# for (( i = 0; i < $num_res; i++ ))
# do
#   f_ind=`expr $i + 1`
#   echo $HREF_links | cut -f $f_ind -d " "
# #  echo $i
# done

