#include <string>
#include <iostream>


void
remove_special_chars(std::string& word)
{
  std::string new_word;
  for (size_t i = 0; i < word.size(); ++i)
    {
      if (!ispunct(word[i]))
	{
	  new_word += word[i];
	}
    }
  word.swap(new_word);
}


void
make_search_str()
{
  std::string stmp;
  bool first = true;
  std::cin>>stmp;
  while (!stmp.empty() || std::cin)
    {
      /* Remove/Strip all special characters, which can not be
       * expressed simply in a URL.
       *
       */
      remove_special_chars(stmp);

      /* Is the string still non-empty. */
      if (!stmp.empty())
	{
	  if (first)
	    {
	      first = false;
	    }
	  else
	    {
	      std::cout<<'+';
	    }

	  std::cout<<stmp;
	}
      stmp.clear();
      std::cin>>stmp;
    }
}



int
main()
{
  make_search_str();
}

