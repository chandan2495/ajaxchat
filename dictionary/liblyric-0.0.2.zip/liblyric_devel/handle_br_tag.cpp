#include <iostream>

using namespace std;


/* What does this file do????
 *
 * [1] Replace all <br> <BR> <bR> <Br> <  BR  >....
 * in general: < [whitespace] (case insensitive)BR [whitespace] (optional)/ [whitespace] > etc....
 * by a single <br> tag.
 *
 * [2] Then, all lines containing \n [whitespace] <br> OR <br>
 * [whitespace] \n are replaced by a single \n. So, in effect, we are
 * replacing all <br> tags with a single \n so that ONLY <br> causes a
 * new line to to emitted. UNHTML does not handle this.
 *
 */




bool
eat_whitespaces()
{
  char ch = cin.get();
  while (cin && isspace(ch))
    {
      ch = cin.get();
    }
  if (cin)
    {
      cin.putback(ch);
      return true;
    }
  return false;
}



bool
try_finding_br_tag()
{
  std::string stmp;

  if (!eat_whitespaces())
    {
      return false;
    }

  char ch = cin.get();
  stmp += ch;
  ch = cin.get();
  if (cin)
    {
      stmp += ch;
    }
  else
    return false;


  /* Maybe BR or something else. */
  stmp[0] = tolower(stmp[0]);
  stmp[1] = tolower(stmp[1]);

  if (stmp == "br")
    {
      cout<<"br";

      /* Read till we get a '>'. */
      ch = cin.get();
      while (cin && ch != '>')
	{
	  ch = cin.get();
	}
      cout<<">";
    }
  else
    {
      cout<<stmp;
    }
  return true;
}



void
handle_br_tag()
{
  char ch = cin.get();
  while (cin)
    {
      cout<<ch;
      if (ch == '<')
	{
	  if (!try_finding_br_tag())
	    {
	      return;
	    }
	}
      ch = cin.get();
    }
}





int
main()
{
  handle_br_tag();
}

