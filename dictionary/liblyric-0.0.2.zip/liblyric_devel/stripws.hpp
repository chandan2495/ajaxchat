#include <string>
#include <vector>
#include <ctype.h>


struct word_t
{
  /* The offset of the word in the original tag-stripped input
   * stream.
   */
  int offset;

  /* The actual word. */
  std::string str;
};





/* FSM for:
 *
 * [1] Stripping out punctuation marks.
 *
 * [2] Replacing all white space characters, and contiguous sequences
 * thereof to a single space character.
 *
 * In the process, also store the offset of each word in the struct
 * corresponding to a word.
 *
 */



struct reformatter_struct
{
  /* Stores state for the above state machine. */

  /* The input stream. */
  std::string input;

  /* Current position of the stream pointer. */
  size_t pos;

  /* The output stream. */
  std::vector<word_t> word_list;


  reformatter_struct(std::string _str = "")
    : input(_str), pos(0)
  { }


};


void
reformat_stream(reformatter_struct& rfs)
{
  size_t& pos = rfs.pos;
  std::string& input = rfs.input;

  std::string tstr;
  size_t _old_pos = pos - 1;

  while (pos < input.size())
    {
      if (isspace(input[pos]))
	{
	  if (!tstr.empty())
	    {
	      /* Add it to the list of words. */
	      word_t _ws;
	      _ws.str.swap(tstr);
	      _ws.offset = _old_pos + 1;
	      rfs.word_list.push_back(_ws);
	    }
	  _old_pos = pos;
	}
      else if (isalnum(input[pos]) 
	       && !ispunct(input[pos]))
	{
	  /* Add it to the current word. */
	  tstr += tolower(input[pos]);
	}
      ++pos;
    }

  if (!tstr.empty())
    {
      /* Add it to the list of words. */
      word_t _ws;
      _ws.str.swap(tstr);
      _ws.offset = _old_pos + 1;
      rfs.word_list.push_back(_ws);
    }


}

