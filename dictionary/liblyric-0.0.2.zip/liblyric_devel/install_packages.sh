currDir=`pwd`

curlExecName=`which curl`
unhtmlExecName=`which unhtml`

if [ "$curlExecName" = "" ]
then
  # CURL wasn't found. Try to install it.
  echo "Curl was not found. Trying to install."
  curlArchName=`find -name "curl*" | head -n 1`
  if [ "$curlArchName" != "" ]
  then
    # CURL install file was found.
    curl_dir=`tar -jvxf $curlArchName`
    curl_dir=`echo $curl_dir | cut -f 1 -d " "`
    cd $curl_dir
    ./configure
    make
    sudo make install
  else
    echo "CURL install file wasn't found."
  fi
fi

cd $currDir

if [ "$unhtmlExecName" = "" ]
then
  echo "UNHTML was not found. Trying to install."
  unhtmlArchName=`fine -name "unhtml*" | head -n 1`
  if [ "$curlArchName" = "" ]
  then
    unhtml_dir=`tar -zvxf unhtmlArchName`
    unhtml_dir=`echo $unhtml_dir | cut -f 1 -d " "`
    cd $unhtml_dir
    make
    sudo make install
  else
    echo "UNHTML install file wasn't found."
  fi
fi

