#include <iostream>
#include <string>


using namespace std;


std::string start, end;


int
main(int nargs, char **args)
{
  if (nargs != 3)
    {
      cerr<<"Please enter the start and end delimiters."<<endl;
      return 1;
    }

  start = args[1];
  end = args[2];

  if (start.empty() || end.empty())
    {
      cerr<<"Please don't enter empty delimiters."<<endl;
      return 2;
    }

//   cerr<<"start == "<<start<<endl
//       <<"end   == "<<end<<endl;


  bool check_start = true;
  int curr_ind = 0;
  std::string buff;

  char ch;
  while (true)
    {
      // cerr<<"ch == "<<ch<<endl;
      std::string *pstr = &start;

      if (!check_start)
	{
	  pstr = &end;
	  buff.clear();
	}


      if (curr_ind == pstr->size())
	{
	  // cerr<<(check_start?"Header":"Trailer")<<" Detected!!!!"<<endl;
	  /* Header detected. Empty buffer. */
	  buff.clear();

	  /* Check Trailer now. */
	  check_start = !check_start;
	  curr_ind = 0;
	  // cin.putback(ch);
	  continue;
	}

      ch = cin.get();
      if (!cin)
	break;


      if (ch == (*pstr)[curr_ind])
	{
	  ++curr_ind;

	  if (check_start)
	    {
	      buff += ch;
	    }
	}
      else
	{
	  if (check_start)
	    {
	      std::cout<<buff;
	      buff.clear();
	      cout<<ch;
	    }

	  curr_ind = 0;
	}
      // ch = cin.get();
    }

  return 0;
}

