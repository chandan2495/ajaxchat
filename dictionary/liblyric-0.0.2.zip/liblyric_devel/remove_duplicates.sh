
./make_pairs.sh | sort -k 1,1 -u | cut -f 2
