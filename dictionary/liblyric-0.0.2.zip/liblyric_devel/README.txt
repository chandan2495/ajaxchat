How to build:
-------------

I assume you have been successfully able to untar the archive, and are
hence at this stage of the installation process.

To install the packages on which liblyric depends, you need to do a:
'make packages'. This will ask you for the root password.

After that, typing a simple 'make' will build the required liblyric
binaries.

You can run the application by simply typing:
./getlyric.sh <song name along with artist(optional)>

So, if you wanted the lyrics to the song "Eclipse" by "Pink Floyd",
you would type:

./getlyric.sh "pink floyd eclipse"

For help, type:

./getlyric.sh --help


Have Fun :-)

Mail me at dhruvbird@gmail.com if you have any
questions/suggestions/criticisms.

