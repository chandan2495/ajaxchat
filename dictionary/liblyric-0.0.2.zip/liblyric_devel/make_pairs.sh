#/bin/bash

# Makes pairs or site name, and URL.

while read line
do
  site_name=`echo $line | cut -f 3 -d "/"`
  site_name=$site_name"\c"
  echo -e $site_name
  echo -e "\t\c"
  echo $line
done

