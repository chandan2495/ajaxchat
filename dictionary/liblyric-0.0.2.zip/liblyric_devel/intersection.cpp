/*  
 *  liblyric Intersector -- Approximation intersection of two distinct
 *  input streams.
 *
 *  Copyright (C) 2006, Dhruv Matani.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */


#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <sstream>
#include <list>
#include <fstream>
#include <ext/hash_map>
#include <assert.h>


#include "stripws.hpp"


#define HASH_MAP __gnu_cxx::hash_multimap



namespace __gnu_cxx
{
  template<typename T>
  struct hash;

  template<>
  struct hash<const std::string>
  {
    size_t
    operator()(std::string const& _s) const
    {
      size_t _h = 0;
      size_t _s_size = _s.size();

      while (_s_size > 0)
	{
	  --_s_size;
	  _h += (_h * 2 + _s[_s_size]);
	}

      return _h;
    }
  };


  template<>
  struct hash<std::string>
  {
    size_t
    operator()(const std::string& _s) const
    { return hash<const std::string>()(_s); }

  };
}


#define DBUG_PRINT(STR) if (debug_on) std::cerr<<STR;





/* This file will accept as input two separate input streams, which
 * correspond to tag-stripped web-pages which need to be re-formatted,
 * and the intersection algorithm run on.
 *
 * The two input streams are to be separated with a <next> tag in
 * between them.
 *
 * The output will be written to stdout. The format of which is as
 * follows. If there was any intersection which exceeded the threshold
 * value, then a 1 is printed, else a 0 is printed. Following this(on
 * a new line), the start offset in the original file(of the word) is
 * printed, and the next line contains the end offset of the last word
 * which intersects.
 *
 */


int continuous_pairs = 24;
int num_mismatches   = 10;
bool debug_on = false;
bool from_stdin = false;




/* Encodes information about a region that has started matching. If we
 * find a match to a pair in a region that is not currently in the
 * list of regions, we create a new region, and add that to the list
 * of regions to be included to considering in the final output. If a
 * match occurs in a position which is just after the last offset
 * added in a particular region, we increment the last offset counter
 * for that region, and increment the cont_pairs variable. Even if the
 * new pair is not in the next position, but is within num_mismatches,
 * we still set the last_offset variable in the region_struct, but
 * don't increment the cont_pairs variable. We don't set nm_mism to
 * zero in this case, but we do in the previous case. Again, if in a
 * run the region's pairs don't match, the num_mism variable is
 * incremented. If num_mism exceeds the num_mismatches variable, then
 * the region is discarded. However, if the region's cont_pairs
 * variable is sufficiently high(2*continuous_pairs), then the region
 * is shifted into the stable stale regions list instead of being
 * discarded. This list is also considered when the final choosing
 * algorithm for the lists is executed.
 *
 * After all is said and done, only those regions with cont_pairs >
 * continuous_pairs are considered. Even from these regions, the ones
 * with the greatest value for cont_pairs is considered. This seems to
 * me to be a tad dicy, but it should work most of the time. The only
 * problem I see with this approach is that regions with disjointed
 * pairs but within num_mismatches may get detected as valid
 * regions. However, for our application, this seems highly
 * unprobable. We can do with it by choosing wise values for the
 * threshold constants.
 *
 */
struct region_struct
{
  /* The start offset of this region in the first input stream. */
  size_t start_offset;

  /* The last offset of this region in the first input stream. */
  size_t last_offset;

  /* The number of continuous pairs encountered till now in this region. */
  int cont_pairs;

  /* The number of continuous mismatched pairs encountered till now. */
  int num_mism;

  /* A list of offsets where the previously matching pairs was found. */
  std::vector<int> prev_offsets;

  region_struct()
    : start_offset(0), last_offset(0), /* other_offset(0), */ cont_pairs(0), num_mism(0)
  { }

};




bool
is_at_distance(std::vector<int>& currv, 
	       std::vector<int>& prevv, 
	       int bkwd_dist, int fwd_dist)
{
  for (size_t i = 0; i < currv.size(); ++i)
    {
      for (size_t j = 0; j < prevv.size(); ++j)
	{
	  if (currv[i] > prevv[j])
	    {
	      if (currv[i] - prevv[j] <= fwd_dist)
		{
		  return true;
		}
	    }
	  else if (prevv[j] - currv[i] <= bkwd_dist)
	    {
	      return true;
	    }
	}
    }
  return false;
}



/** @brief This function performs the approximate intersection of the
 *  two input streams passed to it, and returns a list of possible
 *  matches so that the caller can perform further filtering.
 *
 *  @param sin1 First input stream.
 *
 *  @param sin2 Second input stream.
 *
 */
void
intersect_streams(reformatter_struct& sin1, reformatter_struct& sin2, 
		  std::list<region_struct>& lout)
{
  typedef HASH_MAP<std::string, size_t> pair_map;
  typedef std::list<region_struct> region_list;
  region_list stale_list;
  region_list curr_list;

  /* Step-1: Hash the pair of words in the secomd input stream. */

  pair_map stream2;

  if (sin2.word_list.size() >= 2)
    {
      for (size_t i = 0; i < sin2.word_list.size() - 1; ++i)
	{
	  std::string stmp = sin2.word_list[i].str + ' ' + sin2.word_list[i+1].str;
	  DBUG_PRINT("Inserting: "<<stmp<<std::endl);
	  stream2.insert(pair_map::value_type(stmp, i));
	}
    }

  /* Step-2. Search for each pair in the input stream-1 in the inout
   * stream-2. For each such pair found in stream-2, check if it is
   * belonging to any existing region. If so, add it to that
   * region. Also, create a new region with that pair as the first
   * pair in the new region. Add this new region to the list of
   * currently active regions.
   *
   */
  if (sin1.word_list.size() < 64)
    {
      /* Not worth doing anything here. */
      return;
    }



  for (size_t i = 0; i < sin1.word_list.size() - 1; ++i)
    {
      std::string stmp = sin1.word_list[i].str + ' ' + sin1.word_list[i+1].str;

      // DBUG_PRINT("Processing: "<<stmp<<std::endl);

      size_t cl_sz = curr_list.size();
      DBUG_PRINT("cl_sz: "<<cl_sz<<std::endl);
      std::vector<int> done_mask(cl_sz, 0);

      
      std::pair<pair_map::iterator, pair_map::iterator> matches = 
	stream2.equal_range(stmp);
      bool found_in_stream2 = matches.first != matches.second;

      std::vector<int> p_off;
      for (; matches.first != matches.second; ++matches.first)
	{
	  p_off.push_back(matches.first->second);
	}


      if (found_in_stream2)
	{
	  /* This pair was found in the second stream. We assume that
	   * one of the places it was found is *around* the place of
	   * the previous/regional finding if indicated as TRUE by any
	   * of the two if statements below. This obviously fails if
	   * we have stray pairs being matched at distances very far
	   * away.
	   *
	   * A fix to the above problem has now been implemented. The
	   * function is_at_distance() checks if the pair of words is
	   * at a safe enough distance from the previous occurance. If
	   * not, then the last_offset variable is not incremented.
	   *
	   */
	  DBUG_PRINT("In for loop-1.\n");
	  DBUG_PRINT("Processing: "<<stmp<<std::endl);
	  region_list::iterator rliter = curr_list.begin();
	  int ctr = 0;
	  for (; rliter != curr_list.end(); ++rliter)
	    {
	      /* Is the current offset is one past the one in the
	       * currently being considered region?
	       *
	       */
	      if (done_mask[ctr] == 0 
		  && rliter->last_offset + 1 == i 
		  && is_at_distance(p_off, rliter->prev_offsets, 1, 1))
		{
		  /* Yes, it is. */
		  DBUG_PRINT("Found at location: "<<i<<std::endl);
		  ++(rliter->last_offset);
		  ++(rliter->cont_pairs);
		  rliter->num_mism = 0;
		  ++done_mask[ctr];
		  rliter->prev_offsets = p_off;
		}
	      ++ctr;
	    }

	  rliter = curr_list.begin();
	  ctr = 0;
	  for (; rliter != curr_list.end(); ++rliter)
	    {
	      if (done_mask[ctr] == 0 
		  && i > rliter->last_offset 
		  && (i - rliter->last_offset < (size_t)num_mismatches) 
		  && is_at_distance(p_off, rliter->prev_offsets, 
				    num_mismatches, num_mismatches))
		{
		  /* It is within num_mismatches words of the
		   * currently being considered stream.
		   *
		   */
		  rliter->last_offset = i;
		  ++done_mask[ctr];
		  rliter->prev_offsets = p_off;
		}
	      ++ctr;
	    }


	  /* Since this pair was found in the second stream. There is
	   * a probability of this pair being the starting pair of the
	   * actual lyrics. Add this to curr_list.
	   *
	   */
	  region_struct _rs;
	  _rs.start_offset = _rs.last_offset = i;
	  _rs.prev_offsets = p_off;
	  curr_list.push_back(_rs);
	}


      int _erased = 0;
      for (size_t j = 0; j < cl_sz; ++j)
	{
	  if (done_mask[j] == 0)
	    {
	      /* This particular list was not touched ever. */
	      region_list::iterator titer = curr_list.begin();
	      std::advance(titer, j - _erased);
	      ++titer->num_mism;

	      if (titer->num_mism > num_mismatches)
		{
		  if (titer->cont_pairs > (continuous_pairs * 2))
		    {
		      /* Put this in the stale list. */
		      stale_list.splice(stale_list.end(), curr_list, titer);
		    }
		  else
		    {
		      /* Discard it. */
		      curr_list.erase(titer);
		    }
		  ++_erased;
		}
	    }
	}
    }

  lout.splice(lout.end(), stale_list);

  for (region_list::iterator rliter = curr_list.begin(); 
       rliter != curr_list.end(); )
    {
      if (rliter->cont_pairs > continuous_pairs)
	{
	  region_list::iterator tmpiter = rliter;
	  ++tmpiter;
	  lout.splice(lout.end(), curr_list, rliter);
	  rliter = tmpiter;
	}
      else
	{
	  ++rliter;
	}
    }



}


void
read_file(std::ifstream& fin, std::string& str)
{
  while (true)
    {
      char ch = fin.get();
      if (fin.eof())
	break;
      str += ch;
    }
}


bool
check_for_word(int first, int last, 
	       std::vector<word_t>& word_list, std::string _word, int max_len)
{
  for (int i = 0; i < max_len && first < last; ++i, ++first)
    {
      if (word_list[first].str == _word)
	return true;
    }
  return false;
}




int
main(int nargs, char **args)
{
  /* If there is an argument, then it specifies the threshold value
   * which says how many continuous pair of words should match before
   * we can safely say that an intersection has begun.
   *
   * The second parameter specifies how many mismatches are allowed in
   * the continuous run.
   *
   */

  typedef std::istringstream sin_t;

  /* Input file names. */
  std::string fn1, fn2;


#define INTEGER_EXT_CODE \
	  assert(i+1 < nargs); \
          sin_t sin(args[i+1]);


  for (int i = 1; i < nargs; ++i)
    {
      // std::cerr<<args[i]<<std::endl;
      if (args[i] == std::string("--cp"))
	{
	  INTEGER_EXT_CODE;
	  sin>>continuous_pairs;
	  ++i;
	  continue;
	}

      if (args[i] == std::string("--nm"))
	{
	  INTEGER_EXT_CODE;
	  sin>>num_mismatches;
	  ++i;
	  continue;
	}

      if (args[i] == std::string("--debug"))
	{
	  debug_on = true;
	  continue;
	}

      if (args[i] == std::string("-"))
	{
	  /* Get input from stdin. The two input streams are separated
	   * by the <next> tag.
	   *
	   */
	  from_stdin = true;
	  continue;
	}


      /* Fall through case. These are file names. */
      if (fn1.empty())
	{
	  fn1 = args[i];
	}
      else
	{
	  fn2 = args[i];
	}

    }

  std::string str1, str2;


  if (!from_stdin)
    {
      std::ifstream fin1(fn1.c_str());
      std::ifstream fin2(fn2.c_str());

      assert(fin1);
      assert(fin2);

      read_file(fin1, str1);
      read_file(fin2, str2);
    }
  else
    {
      std::string _tstr;
      char ch = std::cin.get();

      /* Fill in _tstr with the complete input from stdin. */
      while (true)
	{
	  if (std::cin.eof())
	    {
	      break;
	    }
	  _tstr += ch;
	  ch = std::cin.get();
	}

      size_t _pos = _tstr.find("<next>");

      str1 = _tstr.substr(0, _pos);
      str2 = _tstr.substr(_pos + std::string("<next>").size());
    }


  reformatter_struct rs1(str1);
  reformatter_struct rs2(str2);


  reformat_stream(rs1);
  reformat_stream(rs2);



  /*
  std::cout<<std::endl<<"File1:"<<std::endl;
  for (size_t i = 0; i < rs1.word_list.size(); ++i)
    {
      std::cout<<rs1.word_list[i].str<<' ';
    }

  std::cout<<std::endl<<std::endl<<"File2:"<<std::endl;
  for (size_t i = 0; i < rs2.word_list.size(); ++i)
    {
      std::cout<<rs2.word_list[i].str<<' ';
    }
  */


  std::list<region_struct> rout;
  intersect_streams(rs1, rs2, rout);


  DBUG_PRINT("Size: "<<rout.size()<<std::endl);

  region_struct *prs = NULL;

  /* One more filter that removes the following strings if they occur
   * in the first continuous_pairs words of the input:
   *
   * [1] polyphonic
   * [2] ringtones
   * [3] ringtone
   *
   */
  std::list<region_struct>::iterator i = rout.begin();
  std::vector<std::string> bad_words;
  bad_words.push_back("polyphonic");
  bad_words.push_back("ringtones");
  bad_words.push_back("ringtone");


  for (i = rout.begin(); i != rout.end(); ++i)
    {
      for (size_t j = 0; j < bad_words.size(); ++j)
	{
	  if (check_for_word(i->start_offset, i->last_offset + 2, rs1.word_list, 
			     bad_words[j], continuous_pairs))
	    // continue;
	    goto _end_of_outer_loop;
	}

      if (!prs)
	{
	  prs = &(*i);
	}
      else
	{
	  if (i->cont_pairs > prs->cont_pairs)
	    {
	      prs = &(*i);
	    }
	}
	_end_of_outer_loop: ;
    }



  /* Perform some sanity checking. */
  if (!prs)
    {
      /* There was no intersection. */
      std::cout<<"0\t0\t0\t"<<fn1<<std::endl;
    }
  else
    {
      /* There was a substantial amount of approximate intersection. */
      DBUG_PRINT(std::endl<<std::endl<<"THE BIGGIE!!!!:"<<std::endl);

      /* Start offset. */
      int start = rs1.word_list[prs->start_offset].offset;

      /* End offset. */
      int end = rs1.word_list[prs->last_offset + 1].offset 
	/* Size of the last word. */
	+ rs1.word_list[prs->last_offset + 1].str.size();

      std::cout<<end - start<<"\t"<<start<<"\t"<<end<<"\t"<<fn1<<std::endl;

      /* Displays the words with the same formatting as the original input. */
//       copy(str1.begin() + rs1.word_list[prs->start_offset].offset, 
// 	   str1.begin() + rs1.word_list[prs->last_offset + 1].offset + rs1.word_list[prs->last_offset + 1].str.size(), 
// 	   std::ostream_iterator<char>(std::cout));

//      std::cout<<std::endl;
    }
}

