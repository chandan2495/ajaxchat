#include <iostream>
#include <string>
#include <vector>
#include <sstream>

#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <pthread.h>


using namespace std;


vector<string> links;
vector<string> pages;
vector<string> HTML_files;
vector<string> TXT_files;


#define MAX_PAGES 64

std::string liblyric_tmp_dir = "/tmp/liblyric";
std::string proc_tmp_dir;

pthread_mutex_t files_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_t thr[MAX_PAGES];


int num_pages = 0;


void
get_lines()
{
  string stmp;
  cin>>stmp;
  while (!stmp.empty() || cin)
    {
      /* Add the string to the list of links. */
      links.push_back(stmp);
      stmp.clear();
      cin>>stmp;
    }
}


void *
get_pages(void *vptr)
{
  int& i = *(int*)vptr;
  std::ostringstream pind;
  pind<<i;

  std::string curl_cmd_str = "curl --connect-timeout 20 -m 30 \"" + links[i] + "\" 2>> " + proc_tmp_dir + "/curl.err" 

    /* Remove comments. These may span lines, but are enclosed within <!-- and -->. */
    + " | ./remove_bounded_string \\<\\!-- --\\> " 

    /* See the comments in the file handle_br_tag.cpp for a detailed explanation. */
    + " | ./handle_br_tag "

    /* Replace all <br> tags by a single newline. This is dicy,
     * because we are not doing a context-sensitive replace depending
     * on whether the <br> tag occurs within a <pre> and </pre>
     * enclosure.
     */
    + " | sed s/\"<br>\"/\"\\n\"/g "

    /* Replace all '>' by '> '. */
    + " | sed s/\">\"/\"> \"/g " 

    /* Strip out all control characters. */
    + " | sed s/[[:cntrl:]]/""/g > "

    + proc_tmp_dir + "/HTML_page." + pind.str();

  // std::cerr<<"Curl Command: "<<curl_cmd_str<<std::endl;

  std::string unhtml_cmd_str = "unhtml < " + proc_tmp_dir + "/HTML_page." + pind.str() 
    + " > " + proc_tmp_dir + "/page." + pind.str() + " 2>> " + proc_tmp_dir + "/unhtml.err";

  pthread_mutex_lock(&files_lock);
  HTML_files.push_back(proc_tmp_dir + "/HTML_page." + pind.str());
  TXT_files.push_back(proc_tmp_dir + "/page." + pind.str());
  pthread_mutex_unlock(&files_lock);

  system(curl_cmd_str.c_str());
  system(unhtml_cmd_str.c_str());

  delete &i;
  return 0;
}


int
main()
{
  get_lines();
  if (links.size() > MAX_PAGES)
    {
      links.resize(MAX_PAGES);
    }


  mkdir(liblyric_tmp_dir.c_str(), S_IRWXU);

  int _pid = (int)getpid();
  std::ostringstream sout;
  sout<<liblyric_tmp_dir<<"/p."<<_pid;

  proc_tmp_dir = sout.str();

  mkdir(proc_tmp_dir.c_str(), S_IRWXU);

  for (size_t i = 0; i < links.size(); ++i)
    {
      pthread_create(thr+i, NULL, get_pages, (void*)new int(i));
    }

  for (size_t i = 0; i < links.size(); ++i)
    {
      pthread_join(thr[i], NULL);
    }

  /* Perform intersection. */
  for (size_t i = 0; i < TXT_files.size(); ++i)
    {
      for (size_t j = i + 1; j < TXT_files.size(); ++j)
	{
	  /* Intersect page[i] and page[j] both ways. */
	  std::string int_cmd_str1 = "./intersection " + TXT_files[i] + " " + TXT_files[j] 
	    + " >> " + proc_tmp_dir + "/extents.txt";
	  std::string int_cmd_str2 = "./intersection " + TXT_files[j] + " " + TXT_files[i] 
	    + " >> " + proc_tmp_dir + "/extents.txt";

	  system(int_cmd_str1.c_str());
	  system(int_cmd_str2.c_str());

	}
    }

  std::cout<<proc_tmp_dir<<std::endl;


}

