#/bin/sh

OPTSTRING=`getopt -o e:d: -l engine:,debug: -- "$@"`

eval set -- "$OPTSTRING"

engine=''
search_string=''

while true
do
  # echo "Argument: "$1
  case "$1" in
    -e|--engine) engine=$2; shift 2;;
    --) search_string=$2; break;;
    *) echo "Incorrect argument: "$1; shift;;
  esac
done

if [ "$search_string" == "" ]
then
  echo "Please enter the search string."
  exit
fi

gawk_str=''
cut_pos=''
sed_match_exp='*'
sed_replace_exp='*'
agent_param=' -A Mozilla/4.0 '

case "$engine" in
  ask) 
	search_URL="http://www.ask.com/web?q=";
	gawk_str="t\\\" class=\\\"L4\\\" href=\\\".*\\\"";
	cut_pos='5';;
  yahoo) 
	search_URL="http://search.yahoo.com/search?ei=UTF-8\\&n=20\\&b=1\\&p=";
	gawk_str="a class=yschttl  href=\\\".*\\\"";
	cut_pos='2';
	agent_param='';;
  google)
	search_URL="http://www.google.com/search?q=";
	gawk_str="<a href=\\\"[^<>]*\\\" class=l";
	cut_pos='2';;
  dogpile)
	search_URL="http://www.dogpile.com/info.dogpl/search/web/";
	gawk_str="\\\&amp;rawto=[^\\\"]*\\\"";
	cut_pos=2;
	sed_match_exp="rawto=";
	sed_replace_exp="rawto=\\\"";;
  *) echo "Incorrect engine string specified. Please enter either 'ask', 'yahoo', 'google' or 'dogpile'."; exit;;
esac

search_URL=$search_URL$search_string
# echo "search_URL: "$search_URL
# echo "gawk_str: "$gawk_str

# gawk_str="http://"

# Debug version.
# curl $search_URL $agent_param 2> /dev/null 

curl $search_URL $agent_param 2> /dev/null \
  | gawk '{ gsub("'"$gawk_str"'","\nLINK_HERE:&\n"); print $0; }' \
  | grep LINK_HERE \
  | sed s/$sed_match_exp/$sed_replace_exp/g \
  | cut -d "\"" -f $cut_pos

